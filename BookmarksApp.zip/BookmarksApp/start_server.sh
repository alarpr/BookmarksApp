source /Users/alar/Documents/Projektid/BookmarksApp/.venv/bin/activate
uvicorn app.main:app --host 127.0.0.1 --port 8050 --reload