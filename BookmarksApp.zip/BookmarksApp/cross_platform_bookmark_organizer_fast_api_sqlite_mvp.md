# Cross‑platform Bookmark Organizer — FastAPI + SQLite (MVP)

Universaalne, lokaalselt jooksev veebirakendus (Mac, Linux, Windows), mis võimaldab:

- **Importida Safari/“Netscape Bookmarks” HTML** (säilitab kaustahierarhia, kui võimalik)
- **Luua/ümber nimetada/kustutada** teemasid (kaustad) ja alamkaustu
- **Lisada/kustutada/muuta** järjehoidjaid
- **Liigutada** järjehoidjaid kaustade vahel
- **Otsida** (pealkiri või URL)
- **Eelvaade**: parempoolne paneel proovib avada lehe iframe’is *(mõned saidid blokeerivad iframe’i; sel juhul on link „Ava uues aknas”)*
- **Püsisalvestus**: SQLite fail lokaalselt projekti juures

---

## Kaustastruktuur

```
bookmark-organizer/
├─ app/
│  ├─ main.py
│  ├─ models.py
│  ├─ db.py
│  ├─ parse_bookmarks.py
│  ├─ __init__.py
│  ├─ templates/
│  │  ├─ base.html
│  │  └─ topic.html
│  └─ static/
│     ├─ styles.css
│     └─ app.js
├─ requirements.txt
└─ README.md
```

---

## requirements.txt

```txt
fastapi==0.114.2
uvicorn[standard]==0.30.6
jinja2==3.1.4
sqlalchemy==2.0.32
pydantic==2.8.2
python-multipart==0.0.9
beautifulsoup4==4.12.3
```

---

## app/db.py

```python
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
import os

DB_PATH = os.environ.get("BOOKMARK_DB", os.path.join(os.path.dirname(__file__), "..", "bookmarks.sqlite3"))
DB_URL = f"sqlite:///{os.path.abspath(DB_PATH)}"

engine = create_engine(DB_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

# Dependency
from contextlib import contextmanager

@contextmanager
def get_session():
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except:
        session.rollback()
        raise
    finally:
        session.close()
```

---

## app/models.py

```python
from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from .db import Base

class Topic(Base):
    __tablename__ = "topics"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    parent_id = Column(Integer, ForeignKey("topics.id"), nullable=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    parent = relationship("Topic", remote_side=[id], backref="children")
    bookmarks = relationship("Bookmark", back_populates="topic", cascade="all, delete-orphan")

class Bookmark(Base):
    __tablename__ = "bookmarks"

    id = Column(Integer, primary_key=True)
    title = Column(String(512), nullable=False)
    url = Column(Text, nullable=False)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    topic_id = Column(Integer, ForeignKey("topics.id"), index=True, nullable=False)
    topic = relationship("Topic", back_populates="bookmarks")
```

---

## app/parse\_bookmarks.py

```python
from bs4 import BeautifulSoup, Tag
from typing import List, Tuple, Optional

# Safari/Netscape Bookmarks HTML on tüüpiliselt <DL>/<DT>/<H3> kaustad ja <DT><A ...> lingid
# Tagastame listi: (path, title, href), kus path on ["Kaust", "Alamkaust", ...]

def parse_bookmarks_html(html: str) -> List[Tuple[List[str], str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    root_dl = soup.find("dl")
    results: List[Tuple[List[str], str, str]] = []

    def walk(dl: Tag, path: List[str]):
        for dt in dl.find_all("dt", recursive=False):
            h3 = dt.find("h3")
            a = dt.find("a")
            if h3:
                folder_name = h3.get_text(strip=True)
                # Child DL võib olla järgmine sibling
                next_sib = dt.find_next_sibling()
                if isinstance(next_sib, Tag) and next_sib.name.lower() == "dl":
                    walk(next_sib, path + [folder_name])
            elif a and a.has_attr("href"):
                title = a.get_text(strip=True) or a["href"]
                href = a["href"]
                results.append((path, title, href))

    if root_dl:
        walk(root_dl, [])
    else:
        # Lihtne fallback: võta kõik <a> lingid
        for a in soup.find_all("a"):
            if a.has_attr("href"):
                results.append(([], a.get_text(strip=True) or a["href"], a["href"]))

    return results
```

---

## app/main.py

```python
from fastapi import FastAPI, Request, Depends, UploadFile, Form
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import select
from sqlalchemy.orm import joinedload
import os
from typing import Optional

from .db import engine, Base, get_session
from .models import Topic, Bookmark
from .parse_bookmarks import parse_bookmarks_html

app = FastAPI(title="Bookmark Organizer")

BASE_DIR = os.path.dirname(__file__)
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
STATIC_DIR = os.path.join(BASE_DIR, "static")

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=TEMPLATES_DIR)

# Create DB tables
Base.metadata.create_all(bind=engine)

# Helpers

def get_root_topic(session):
    root = session.execute(select(Topic).where(Topic.parent_id == None, Topic.name == "Minu kogud")).scalar_one_or_none()
    if not root:
        root = Topic(name="Minu kogud", parent_id=None)
        session.add(root)
        session.commit()
    return root


def ensure_topic_path(session, path):
    # path: ["Elektroonika", "Mikrokontrollerid"]
    parent = get_root_topic(session)
    for name in path:
        existing = session.execute(select(Topic).where(Topic.parent_id == parent.id, Topic.name == name)).scalar_one_or_none()
        if not existing:
            existing = Topic(name=name, parent_id=parent.id)
            session.add(existing)
            session.commit()
        parent = existing
    return parent


@app.get("/", response_class=HTMLResponse)
def index(request: Request, session=Depends(get_session), q: Optional[str] = None, topic_id: Optional[int] = None, open_url: Optional[str] = None):
    root = get_root_topic(session)

    # load full tree lazily (children relation used in template)
    def fetch_children(t: Topic):
        session.refresh(t)
        for child in t.children:
            fetch_children(child)

    fetch_children(root)

    # determine current topic
    current: Topic
    if topic_id:
        current = session.get(Topic, topic_id) or root
    else:
        # first non-root child if exists
        current = root.children[0] if root.children else root

    # bookmarks for current topic (with optional search)
    bookmarks = current.bookmarks
    if q:
        ql = q.lower()
        bookmarks = [b for b in bookmarks if ql in (b.title or "").lower() or ql in (b.url or "").lower()]

    return templates.TemplateResponse("topic.html", {
        "request": request,
        "root": root,
        "current": current,
        "bookmarks": bookmarks,
        "q": q or "",
        "open_url": open_url,
    })


# Topic CRUD
@app.post("/topics/create")
def create_topic(name: str = Form(...), parent_id: Optional[int] = Form(None), session=Depends(get_session)):
    parent = session.get(Topic, parent_id) if parent_id else get_root_topic(session)
    t = Topic(name=name.strip() or "Uus kaust", parent_id=parent.id if parent else None)
    session.add(t)
    session.commit()
    return RedirectResponse(url=f"/?topic_id={t.id}", status_code=303)


@app.post("/topics/rename/{topic_id}")
def rename_topic(topic_id: int, name: str = Form(...), session=Depends(get_session)):
    t = session.get(Topic, topic_id)
    if t:
        t.name = name.strip() or t.name
        session.commit()
    return RedirectResponse(url=f"/?topic_id={topic_id}", status_code=303)


@app.post("/topics/delete/{topic_id}")
def delete_topic(topic_id: int, session=Depends(get_session)):
    t = session.get(Topic, topic_id)
    root = get_root_topic(session)
    if t and t.id != root.id:
        parent_id = t.parent_id or root.id
        session.delete(t)
        session.commit()
        return RedirectResponse(url=f"/?topic_id={parent_id}", status_code=303)
    return RedirectResponse(url="/", status_code=303)


# Bookmark CRUD
@app.post("/bookmarks/create")
def create_bookmark(title: str = Form(...), url: str = Form(...), topic_id: int = Form(...), session=Depends(get_session)):
    b = Bookmark(title=title.strip() or url, url=url.strip(), topic_id=topic_id)
    session.add(b)
    session.commit()
    return RedirectResponse(url=f"/?topic_id={topic_id}&open_url={b.url}", status_code=303)


@app.post("/bookmarks/delete/{bookmark_id}")
def delete_bookmark(bookmark_id: int, session=Depends(get_session)):
    b = session.get(Bookmark, bookmark_id)
    topic_id = b.topic_id if b else None
    if b:
        session.delete(b)
        session.commit()
    return RedirectResponse(url=f"/?topic_id={topic_id}", status_code=303)


@app.post("/bookmarks/move/{bookmark_id}")
def move_bookmark(bookmark_id: int, target_topic_id: int = Form(...), session=Depends(get_session)):
    b = session.get(Bookmark, bookmark_id)
    if b and session.get(Topic, target_topic_id):
        b.topic_id = target_topic_id
        session.commit()
        return RedirectResponse(url=f"/?topic_id={target_topic_id}", status_code=303)
    return RedirectResponse(url="/", status_code=303)


# Import & Export
@app.post("/import")
def import_bookmarks(file: UploadFile, session=Depends(get_session)):
    html = file.file.read().decode("utf-8", errors="ignore")
    items = parse_bookmarks_html(html)

    for path, title, href in items:
        parent = ensure_topic_path(session, path)
        session.add(Bookmark(title=title, url=href, topic_id=parent.id))
    session.commit()

    return RedirectResponse(url="/", status_code=303)


@app.get("/export", response_class=HTMLResponse)
def export_html(session=Depends(get_session)):
    # Lihtne Netscape Bookmarks HTML
    root = session.execute(select(Topic).where(Topic.parent_id == None)).scalars().all()

    def render_topic(t: Topic) -> str:
        parts = [f"<DT><H3>{t.name}</H3>\n<DL><p>\n"]
        for b in t.bookmarks:
            parts.append(f"<DT><A HREF=\"{b.url}\">{b.title}</A>\n")
        for c in t.children:
            parts.append(render_topic(c))
        parts.append("</DL><p>\n")
        return "".join(parts)

    body = ["<!DOCTYPE NETSCAPE-Bookmark-file-1>\n<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">\n<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n<DL><p>\n"]
    for r in root:
        body.append(render_topic(r))
    body.append("</DL><p>\n")

    return HTMLResponse(content="".join(body), media_type="text/html")
```

---

## app/templates/base.html

```html
<!DOCTYPE html>
<html lang="et">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Bookmark Organizer</title>
  <link rel="stylesheet" href="/static/styles.css" />
</head>
<body>
  <header>
    <h1>Bookmark Organizer</h1>
    <nav>
      <form action="/import" method="post" enctype="multipart/form-data">
        <label class="btn">Import HTML<input type="file" name="file" accept="text/html,.html" onchange="this.form.submit()" hidden></label>
      </form>
      <a class="btn" href="/export" target="_blank">Export HTML</a>
    </nav>
  </header>
  <main>
    {% block content %}{% endblock %}
  </main>
  <script src="/static/app.js"></script>
</body>
</html>
```

---

## app/templates/topic.html

```html
{% extends "base.html" %}
{% block content %}
<div class="layout">
  <aside class="sidebar">
    <div class="sidebar-header">
      <form action="/topics/create" method="post">
        <input type="hidden" name="parent_id" value="{{ current.id if current else '' }}">
        <input type="text" name="name" placeholder="Uus kaust" required>
        <button>Lisa</button>
      </form>
    </div>

    <ul class="tree">
      {# rekursiivne puu #}
      {% macro render_topic(t, current_id) %}
        <li>
          <div class="node {{ 'active' if t.id == current_id else '' }}">
            <a href="/?topic_id={{ t.id }}">📁 {{ t.name }}</a>
            {% if t.id != (root.id if root else -1) %}
            <details>
              <summary>Tööriistad</summary>
              <form action="/topics/rename/{{ t.id }}" method="post">
                <input name="name" value="{{ t.name }}" />
                <button>Uuenda</button>
              </form>
              <form action="/topics/delete/{{ t.id }}" method="post" onsubmit="return confirm('Kustuta kaust?');">
                <button class="danger">Kustuta</button>
              </form>
            </details>
            {% endif %}
          </div>
          {% if t.children %}
            <ul>
              {% for c in t.children %}
                {{ render_topic(c, current_id) }}
              {% endfor %}
            </ul>
          {% endif %}
        </li>
      {% endmacro %}

      {% if root %}
        {{ render_topic(root, current.id if current else -1) }}
      {% endif %}
    </ul>
  </aside>

  <section class="list">
    <div class="toolbar">
      <form method="get" action="/">
        <input type="hidden" name="topic_id" value="{{ current.id if current else '' }}">
        <input type="search" name="q" value="{{ q }}" placeholder="Otsi pealkirjast või URL-ist">
        <button>Otsi</button>
      </form>

      <form action="/bookmarks/create" method="post" class="inline">
        <input type="hidden" name="topic_id" value="{{ current.id }}">
        <input name="title" placeholder="Pealkiri" required>
        <input name="url" placeholder="https://…" required>
        <button>Lisa link</button>
      </form>
    </div>

    {% if bookmarks %}
      <table class="grid">
        <thead>
          <tr><th>Pealkiri</th><th>URL</th><th>Tegevused</th></tr>
        </thead>
        <tbody>
        {% for b in bookmarks %}
          <tr onclick="openPreview('{{ b.url|e }}')">
            <td>{{ b.title }}</td>
            <td><a href="{{ b.url }}" target="_blank" onclick="event.stopPropagation();">{{ b.url }}</a></td>
            <td class="actions">
              <form action="/bookmarks/delete/{{ b.id }}" method="post" onsubmit="return confirm('Kustuta link?');">
                <button class="danger" onclick="event.stopPropagation();">Kustuta</button>
              </form>
              <form action="/bookmarks/move/{{ b.id }}" method="post" class="inline" onclick="event.stopPropagation();">
                <select name="target_topic_id">
                  {% for c in root.children %}
                    {% for opt, depth in namespace(opts=[]) %}{% endfor %}
                  {% endfor %}
                  {# lihtne flattitud valik: #}
                  {% set stack = [(root, 0)] %}
                  {% for item in stack %}{% endfor %}
                  {% macro options(t, depth) %}
                    <option value="{{ t.id }}" {{ 'selected' if t.id == b.topic_id else '' }}>{{ '-- ' * depth }}{{ t.name }}</option>
                    {% for ch in t.children %}
                      {{ options(ch, depth + 1) }}
                    {% endfor %}
                  {% endmacro %}
                  {{ options(root, 0) }}
                </select>
                <button>Liiguta</button>
              </form>
            </td>
          </tr>
        {% endfor %}
        </tbody>
      </table>
    {% else %}
      <p class="muted">(Selles kaustas hetkel kirjeid pole)</p>
    {% endif %}
  </section>

  <aside class="preview">
    {% if open_url %}
      <iframe src="{{ open_url }}" referrerpolicy="no-referrer" sandbox="allow-scripts allow-same-origin allow-forms allow-popups"></iframe>
      <div class="fallback">
        <a class="btn" href="{{ open_url }}" target="_blank">Ava uues aknas</a>
      </div>
    {% else %}
      <div class="muted center">Vali vasakult link eelvaateks</div>
    {% endif %}
  </aside>
</div>
{% endblock %}
```

---

## app/static/styles.css

```css
:root { --bg:#0b0c10; --card:#13141a; --text:#e9eaee; --muted:#9aa0aa; --accent:#4f8cff; --danger:#ff5252; }
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);font:14px/1.5 -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Inter,Ubuntu}
header{display:flex;justify-content:space-between;align-items:center;padding:10px 16px;background:var(--card);border-bottom:1px solid #222}
h1{font-size:18px;margin:0}
.btn{display:inline-block;padding:6px 10px;background:var(--accent);color:white;border-radius:8px;text-decoration:none;margin-left:8px}
.btn input{display:none}
main{height:calc(100vh - 52px)}
.layout{display:grid;grid-template-columns:280px 1fr 40vw;height:100%}
.sidebar{overflow:auto;border-right:1px solid #222;background:#0f1016}
.sidebar-header{padding:8px;border-bottom:1px solid #222}
.sidebar form input{width:55%;padding:6px;background:#0b0b11;border:1px solid #2a2a33;color:var(--text);border-radius:6px}
.sidebar form button{margin-left:6px;padding:6px 10px;border-radius:6px}
.tree{list-style:none;margin:0;padding:8px}
.node{display:flex;gap:8px;align-items:center;justify-content:space-between;padding:4px 6px;border-radius:6px}
.node.active{background:#1a1d26}
.node details{margin-left:auto}
.danger{background:var(--danger);color:#fff;border:none;padding:6px 8px;border-radius:6px}
.list{overflow:auto;padding:10px}
.toolbar{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:10px}
.toolbar input[type="search"], .toolbar input[name="title"], .toolbar input[name="url"]{padding:6px 8px;border-radius:6px;border:1px solid #2a2a33;background:#0b0b11;color:var(--text)}
.toolbar button{padding:6px 10px;border-radius:6px;border:none;background:var(--accent);color:#fff}
.grid{width:100%;border-collapse:collapse}
.grid th,.grid td{border-bottom:1px solid #222;padding:8px;text-align:left}
.grid tr:hover{background:#161822;cursor:pointer}
.actions{display:flex;gap:8px}
.preview{border-left:1px solid #222;display:flex;flex-direction:column}
.preview iframe{flex:1;border:0}
.fallback{padding:8px;border-top:1px solid #222}
.muted{color:var(--muted)}
.center{display:flex;align-items:center;justify-content:center;height:100%}
```

---

## app/static/app.js

```js
function openPreview(url){
  const u = new URL(window.location);
  u.searchParams.set('open_url', url);
  window.location = u.toString();
}
```

---

## README.md

````md
# Bookmark Organizer (FastAPI + SQLite)

Lokaalne, universaalne (macOS/Linux/Windows) veebirakendus järjehoidjate korrastamiseks.

## Kiire start

1. **Python 3.11+** (soovituslik). Loo virtuaalkeskkond ja paigalda sõltuvused:

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
````

2. **Käivita**

```bash
uvicorn app.main:app --reload
```

Ava brauseris: [http://127.0.0.1:8000](http://127.0.0.1:8000)

3. **Import**: Headeris "Import HTML" – vali Safari eksporditud Bookmarks HTML.

## Märkused

- Safari HTML hierarhia tuuakse üle: kaustad/alamkaustad → rakenduse kaustad.
- Iframe eelvaade ei tööta saitidel, mis on X-Frame-Options/Content-Security-Policy tõttu blokeeritud. Kasuta nuppu "Ava uues aknas".
- Andmebaas on `bookmarks.sqlite3` (muudetav `BOOKMARK_DB` env-muutujaga).

## Järgmised sammud (soovi korral)

- Drag & drop kaustade ja linkide ümbertõstmine (HTML5 DnD)
- Mass-import valve (duplikaatide tuvastus)
- Linkide tervisekontroll (HEAD/GET ja 4xx/5xx märgistus)
- Faviconi ja meta-pealkirja automaatne tõmbamine
- Kasutajate rollid + pilve deploy (Fly.io/Dokku/Render/Heroku)
- Ekspordi valikud: JSON/Markdown/CSV lisaks HTML-ile

```
```
